﻿
namespace AİÇÜ_Staj_Projesi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.pcrBAcikUser = new System.Windows.Forms.PictureBox();
            this.pcrBKapaliUser = new System.Windows.Forms.PictureBox();
            this.pcrBAcikSifre = new System.Windows.Forms.PictureBox();
            this.pcrBKapaliSifre = new System.Windows.Forms.PictureBox();
            this.toolTipOgrenciNo = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.pcrBAcikGiris = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBAcikUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBKapaliUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBAcikSifre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBKapaliSifre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBAcikGiris)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::AİÇÜ_Staj_Projesi.Properties.Resources.A_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(359, 67);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(327, 245);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // txtSifre
            // 
            this.txtSifre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.txtSifre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSifre.Font = new System.Drawing.Font("Microsoft YaHei UI", 17F, System.Drawing.FontStyle.Bold);
            this.txtSifre.Location = new System.Drawing.Point(367, 408);
            this.txtSifre.Multiline = true;
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.PasswordChar = '*';
            this.txtSifre.Size = new System.Drawing.Size(267, 37);
            this.txtSifre.TabIndex = 1;
            this.toolTipOgrenciNo.SetToolTip(this.txtSifre, "* Öğrenci Şifre");
            this.txtSifre.TextChanged += new System.EventHandler(this.txtSifre_TextChanged);
            this.txtSifre.MouseLeave += new System.EventHandler(this.txtSifre_MouseLeave);
            this.txtSifre.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtSifre_MouseMove);
            // 
            // txtAd
            // 
            this.txtAd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtAd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAd.Font = new System.Drawing.Font("Microsoft YaHei UI", 17F, System.Drawing.FontStyle.Bold);
            this.txtAd.Location = new System.Drawing.Point(367, 351);
            this.txtAd.Multiline = true;
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(267, 38);
            this.txtAd.TabIndex = 0;
            this.toolTipOgrenciNo.SetToolTip(this.txtAd, "* Öğrenci NO");
            this.txtAd.TextChanged += new System.EventHandler(this.txtAd_TextChanged);
            this.txtAd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAd_KeyPress);
            this.txtAd.MouseLeave += new System.EventHandler(this.txtAd_MouseLeave);
            this.txtAd.MouseMove += new System.Windows.Forms.MouseEventHandler(this.textBox2_MouseMove);
            // 
            // pcrBAcikUser
            // 
            this.pcrBAcikUser.BackColor = System.Drawing.Color.Transparent;
            this.pcrBAcikUser.Image = global::AİÇÜ_Staj_Projesi.Properties.Resources.user_Acilk;
            this.pcrBAcikUser.Location = new System.Drawing.Point(633, 351);
            this.pcrBAcikUser.Name = "pcrBAcikUser";
            this.pcrBAcikUser.Size = new System.Drawing.Size(48, 38);
            this.pcrBAcikUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrBAcikUser.TabIndex = 0;
            this.pcrBAcikUser.TabStop = false;
            // 
            // pcrBKapaliUser
            // 
            this.pcrBKapaliUser.BackColor = System.Drawing.Color.Transparent;
            this.pcrBKapaliUser.Image = global::AİÇÜ_Staj_Projesi.Properties.Resources.user_Kapali;
            this.pcrBKapaliUser.Location = new System.Drawing.Point(633, 351);
            this.pcrBKapaliUser.Name = "pcrBKapaliUser";
            this.pcrBKapaliUser.Size = new System.Drawing.Size(48, 38);
            this.pcrBKapaliUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrBKapaliUser.TabIndex = 0;
            this.pcrBKapaliUser.TabStop = false;
            this.pcrBKapaliUser.Visible = false;
            // 
            // pcrBAcikSifre
            // 
            this.pcrBAcikSifre.BackColor = System.Drawing.Color.Transparent;
            this.pcrBAcikSifre.Image = global::AİÇÜ_Staj_Projesi.Properties.Resources.userKey_Acik;
            this.pcrBAcikSifre.Location = new System.Drawing.Point(633, 408);
            this.pcrBAcikSifre.Name = "pcrBAcikSifre";
            this.pcrBAcikSifre.Size = new System.Drawing.Size(48, 37);
            this.pcrBAcikSifre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrBAcikSifre.TabIndex = 0;
            this.pcrBAcikSifre.TabStop = false;
            // 
            // pcrBKapaliSifre
            // 
            this.pcrBKapaliSifre.BackColor = System.Drawing.Color.Transparent;
            this.pcrBKapaliSifre.Image = global::AİÇÜ_Staj_Projesi.Properties.Resources.userKey_Kapali100;
            this.pcrBKapaliSifre.Location = new System.Drawing.Point(633, 408);
            this.pcrBKapaliSifre.Name = "pcrBKapaliSifre";
            this.pcrBKapaliSifre.Size = new System.Drawing.Size(48, 37);
            this.pcrBKapaliSifre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrBKapaliSifre.TabIndex = 0;
            this.pcrBKapaliSifre.TabStop = false;
            this.pcrBKapaliSifre.Visible = false;
            // 
            // toolTipOgrenciNo
            // 
            this.toolTipOgrenciNo.AutomaticDelay = 250;
            this.toolTipOgrenciNo.AutoPopDelay = 1000;
            this.toolTipOgrenciNo.BackColor = System.Drawing.SystemColors.Highlight;
            this.toolTipOgrenciNo.ForeColor = System.Drawing.Color.Black;
            this.toolTipOgrenciNo.InitialDelay = 250;
            this.toolTipOgrenciNo.IsBalloon = true;
            this.toolTipOgrenciNo.ReshowDelay = 50;
            this.toolTipOgrenciNo.ShowAlways = true;
            this.toolTipOgrenciNo.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTipOgrenciNo.ToolTipTitle = "Bilgilendirme";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label1.Location = new System.Drawing.Point(318, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(410, 46);
            this.label1.TabIndex = 2;
            this.label1.Text = "Öğrenci Bilgi Sistemi";
            // 
            // pcrBAcikGiris
            // 
            this.pcrBAcikGiris.BackColor = System.Drawing.Color.Transparent;
            this.pcrBAcikGiris.Image = global::AİÇÜ_Staj_Projesi.Properties.Resources.uye_giris;
            this.pcrBAcikGiris.Location = new System.Drawing.Point(410, 441);
            this.pcrBAcikGiris.Name = "pcrBAcikGiris";
            this.pcrBAcikGiris.Size = new System.Drawing.Size(199, 175);
            this.pcrBAcikGiris.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrBAcikGiris.TabIndex = 0;
            this.pcrBAcikGiris.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::AİÇÜ_Staj_Projesi.Properties.Resources.AİCUArkaPlan4;
            this.ClientSize = new System.Drawing.Size(1048, 649);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAd);
            this.Controls.Add(this.txtSifre);
            this.Controls.Add(this.pcrBAcikGiris);
            this.Controls.Add(this.pcrBKapaliSifre);
            this.Controls.Add(this.pcrBAcikSifre);
            this.Controls.Add(this.pcrBKapaliUser);
            this.Controls.Add(this.pcrBAcikUser);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBAcikUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBKapaliUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBAcikSifre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBKapaliSifre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBAcikGiris)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.PictureBox pcrBAcikUser;
        private System.Windows.Forms.PictureBox pcrBKapaliUser;
        private System.Windows.Forms.PictureBox pcrBAcikSifre;
        private System.Windows.Forms.PictureBox pcrBKapaliSifre;
        private System.Windows.Forms.ToolTip toolTipOgrenciNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pcrBAcikGiris;
    }
}

