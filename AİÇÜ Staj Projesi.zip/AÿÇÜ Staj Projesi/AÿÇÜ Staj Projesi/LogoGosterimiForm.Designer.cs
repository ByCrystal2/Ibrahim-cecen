﻿
namespace AİÇÜ_Staj_Projesi
{
    partial class LogoGosterimiForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pcrbGirisLogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pcrbGirisLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pcrbGirisLogo
            // 
            this.pcrbGirisLogo.BackColor = System.Drawing.Color.Transparent;
            this.pcrbGirisLogo.Image = global::AİÇÜ_Staj_Projesi.Properties.Resources.AgriUniLogo_removebg_preview;
            this.pcrbGirisLogo.Location = new System.Drawing.Point(0, 0);
            this.pcrbGirisLogo.Name = "pcrbGirisLogo";
            this.pcrbGirisLogo.Size = new System.Drawing.Size(417, 491);
            this.pcrbGirisLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrbGirisLogo.TabIndex = 0;
            this.pcrbGirisLogo.TabStop = false;
            // 
            // LogoGosterimiForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 490);
            this.Controls.Add(this.pcrbGirisLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(1, 1);
            this.Name = "LogoGosterimiForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.TransparencyKey = System.Drawing.SystemColors.Control;
            this.Load += new System.EventHandler(this.LogoGosterimiForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcrbGirisLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pcrbGirisLogo;
        private System.Windows.Forms.Timer timer1;
    }
}