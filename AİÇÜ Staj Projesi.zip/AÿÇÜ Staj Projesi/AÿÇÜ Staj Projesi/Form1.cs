﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AİÇÜ_Staj_Projesi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random r1 = new Random();
        Random r2 = new Random();
        Random r3 = new Random();
        Random r4 = new Random();

        int rndm1,rndm2,rndm3,rndm4,toplam;
        
        private void Form1_Load(object sender, EventArgs e)
        {
             rndm1 = r1.Next(0, 500);
             rndm2 = r2.Next(500, 1000);





        }

        bool yazdiMiUser = false;
        bool yazdiMiSifre = false;

        #region TextBoxlar Mouse Gelme Olayları
        private void textBox2_MouseMove(object sender, MouseEventArgs e)
        {
            
            pcrBAcikUser.Visible = false;
            pcrBKapaliUser.Visible = true;
        }
        private void txtSifre_MouseMove(object sender, MouseEventArgs e)
        {
            pcrBAcikSifre.Visible = false;
            pcrBKapaliSifre.Visible = true;
        }
        #endregion

        #region TextBoxlar Mouse Çıkışı Olayları
        private void txtAd_MouseLeave(object sender, EventArgs e)
        {
            if (yazdiMiUser == false)
            {
                pcrBKapaliUser.Visible = false;
                pcrBAcikUser.Visible = true;
            }
            else
                return;
        }
        private void txtSifre_MouseLeave(object sender, EventArgs e)
        {
            if (yazdiMiSifre == false)
            {
                pcrBKapaliSifre.Visible = false;
                pcrBAcikSifre.Visible = true;
            }
            else
                return;
        }
        #endregion

        #region Yazı Girilme Durumları (Visiable olayları)
        private void txtAd_TextChanged(object sender, EventArgs e)
        {
            
            yazdiMiUser = true;
            pcrBAcikUser.Visible = false;
            pcrBKapaliUser.Visible = true;
            if(txtAd.Text == "")
            {
                yazdiMiUser = false;
                pcrBAcikUser.Visible = true;
                pcrBKapaliUser.Visible = false;
            }

        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {
            yazdiMiSifre = true;
            pcrBAcikSifre.Visible = false;
            pcrBKapaliSifre.Visible = true;
            if(txtSifre.Text == "")
            {
                yazdiMiSifre = false;
                pcrBAcikSifre.Visible = true;
                pcrBKapaliSifre.Visible = false;
            }
            
        }
#endregion


        private void txtAd_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
           
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }



        SqlConnection baglanti = new SqlConnection("Data Source=BILGIIŞLEM;Initial Catalog=Kitaplık;Integrated Security=True");

      

        private void txtGuvenlik_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void pcrBAcikGiris_Click(object sender, EventArgs e)
        {
            
       

        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            int toplam = rndm1 + rndm2;

            txtGuvenlikSoru.Text = rndm1.ToString() + " + " + rndm2.ToString() + " =";

            if (txtGuvenlik.Text != toplam.ToString())
            {
                pcrbKapaliGuvenlik.Visible = true;
                pcrbAcikGuvenlik.Visible = false;
            }
            else
            {
                pcrbAcikGuvenlik.Visible = true;
                pcrbKapaliGuvenlik.Visible = false;
            }
        }
        int sure = 0;
        private void tickGuvenlikSure_Tick(object sender, EventArgs e)// en son kalınan yer 23.09.2021 16.42
        {
            rndm3 = r3.Next(0, 500);
            rndm4 = r4.Next(500, 1000);
            
               sure = tickGuvenlikSure.Interval/100;
            lblGuvenlikSure.Text = sure.ToString();
            if(sure == 60)
            {
                sure = 0;
               
            }
        }
    }
}
