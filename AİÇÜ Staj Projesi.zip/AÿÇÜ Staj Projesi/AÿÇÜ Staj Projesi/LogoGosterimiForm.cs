﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AİÇÜ_Staj_Projesi
{
    public partial class LogoGosterimiForm : Form
    {
        public LogoGosterimiForm()
        {
            InitializeComponent();
        }

        private void LogoGosterimiForm_Load(object sender, EventArgs e)
        {
            
        }
        int tikci = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
                tikci += 1000;
            if (tikci == 7000)
            {
                this.Hide();
                Form1 frm = new Form1();
                frm.Show();
                timer1.Enabled = false;
            }
            
        }
    }
}
